# StudioForge 2.2 — Windows Fix Pack

## আপনার দুইটি WinError 2 সমস্যার সংশোধন

**Competitor Analysis:** আগের কোডে `yt-dlp` executable সরাসরি PATH থেকে চালানো হতো। Windows virtual environment-এ `yt-dlp.exe` PATH-এ না থাকলে `[WinError 2]` আসত। এখন Streamlit যে Python environment দিয়ে চলছে, সেই একই interpreter দিয়ে `python -m yt_dlp` চালানো হয়। Channel URL-এর `?si=...` tracking অংশ বাদ দিয়ে `/videos` endpoint ব্যবহার করা হয়। Thumbnail download ব্যর্থ হলেও পুরো analysis আর crash করবে না।

**Voice/Video Rendering:** `ffprobe`-এর ওপর নির্ভরতা নেই। FFmpeg system PATH-এ না থাকলেও `imageio-ffmpeg`-এর bundled executable ব্যবহার হবে। Render subprocess error হলে বিস্তারিত FFmpeg message দেখাবে।

## গুরুত্বপূর্ণ: পুরোনো Studio যেন না খোলে

স্ক্রিনশটে Build 1.1 দেখা যাচ্ছে। এর মানে পুরোনো app instance/পুরোনো folder চালু থাকতে পারে। Build 2.2 আলাদা port **8503** ব্যবহার করে, যাতে পুরোনো 8501-এর সঙ্গে গুলিয়ে না যায়।

1. পুরোনো Studio-র Command Prompt/Terminal-এ `Ctrl + C` চাপুন এবং পুরোনো Browser tab বন্ধ করুন।
2. এই ZIP নতুন আলাদা folder-এ Extract করুন। পুরোনো folder-এর ওপর overwrite করবেন না।
3. `setup_windows.bat` একবার চালান।
4. কোনো package missing থাকলে `repair_environment.bat` চালান।
5. `run_windows.bat` চালান।
6. নতুন Studio খুলুন: **http://localhost:8503**
7. Sidebar-এ **STUDIOFORGE 2.2** লেখা আছে কি না দেখুন। যদি Build 1.1 বা 1.2 দেখায়, তাহলে পুরোনো app-ই চলছে।

## Diagnostics

`check_environment.bat` Streamlit, Pillow, yt-dlp এবং bundled FFmpeg detect করে। Competitor research-এর জন্য internet connection ও public YouTube channel প্রয়োজন।

## Test notes

এই build-এর Python files compile করা হয়েছে। Local test-এ bundled FFmpeg দিয়ে synthetic audio + generated scene image থেকে MP4 এবং SRT render সফল হয়েছে। আপনার Windows machine-এ YouTube access, TTS voices, antivirus permissions, installed dependencies আলাদা হতে পারে; তাই আপনার PC-তে install করে শেষবার যাচাই করতে হবে।

## Limits

Competitor style detection public titles ও available thumbnails-এর heuristic; competitor-এর exact editing pipeline/private analytics জানা যায় না। Local scene images Pillow illustration; external generative image model নয়। 3D style 2.5D। YouTube upload-এর জন্য OAuth client এবং YouTube Data API v3 সেটআপ লাগবে।
