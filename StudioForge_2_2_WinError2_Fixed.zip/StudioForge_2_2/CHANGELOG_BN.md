# Update 1.1 — Windows Render Fix + UI Refresh

### Bug fix
- Previous render crash was caused by `subprocess` trying to execute `ffprobe` when it was not installed or not available in Windows PATH (`FileNotFoundError / WinError 2`).
- Duration detection now uses the FFmpeg executable itself and parses its input metadata; it no longer requires `ffprobe`.
- FFmpeg lookup now checks `FFMPEG_BINARY`, system PATH, then the portable `imageio-ffmpeg` binary.
- FFmpeg errors are caught and surfaced in the app rather than leaving the user with an unhandled Streamlit traceback.

### Interface refresh
- Replaced plain Streamlit styling with an original dark creator-workspace theme.
- Added workspace sidebar, status cards, gradient hero, production dashboard, clearer labels and consistent tabs/controls.
- Removed the external web-font dependency; system fonts are used so the interface remains local-first.

### Validation performed in build environment
- Python compileall: passed.
- FFmpeg binary discovery: passed.
- Audio duration detection without ffprobe: passed.
- Short sample MP4 render with audio and subtitles: passed.

The final user's Windows machine still needs to run `setup_windows.bat` to install the updated dependencies.
