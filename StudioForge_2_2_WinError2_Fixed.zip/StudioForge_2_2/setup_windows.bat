@echo off
setlocal
cd /d "%~dp0"
echo [1/4] Creating virtual environment...
if not exist .venv\Scripts\python.exe py -3 -m venv .venv
if errorlevel 1 goto fail
echo [2/4] Upgrading pip...
.venv\Scripts\python.exe -m pip install --upgrade pip
if errorlevel 1 goto fail
echo [3/4] Installing Studio dependencies (includes portable FFmpeg)...
.venv\Scripts\python.exe -m pip install -r requirements.txt
if errorlevel 1 goto fail
echo [4/4] Setup complete.
echo Optional word timing: run install_word_sync.bat
pause
exit /b 0
:fail
echo Setup failed. Check your internet connection and Python installation.
pause
exit /b 1
