@echo off
setlocal
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe (
 echo Please run setup_windows.bat first.
 pause
 exit /b 1
)
echo Starting StudioForge 2.2 on http://localhost:8503
.venv\Scripts\python.exe -m streamlit run app\main.py --server.port 8503 --server.address 127.0.0.1
pause
