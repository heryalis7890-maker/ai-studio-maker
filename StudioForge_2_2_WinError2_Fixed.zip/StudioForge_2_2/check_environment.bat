@echo off
setlocal
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe (
 echo Virtual environment missing. Run setup_windows.bat first.
 pause
 exit /b 1
)
.venv\Scripts\python.exe -c "import streamlit, PIL, imageio_ffmpeg, yt_dlp; print('Streamlit:',streamlit.__version__); print('Pillow:',PIL.__version__); print('yt-dlp:',yt_dlp.version.__version__); print('FFmpeg:',imageio_ffmpeg.get_ffmpeg_exe())"
if errorlevel 1 echo One or more packages are missing. Run repair_environment.bat.
pause
