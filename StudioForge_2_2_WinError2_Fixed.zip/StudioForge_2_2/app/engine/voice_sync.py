"""Local TTS, optional Whisper word timestamps and subtitle generation."""
from pathlib import Path
import subprocess,re,shutil,os

def list_local_voices():
 try:
  import pyttsx3; e=pyttsx3.init();vs=e.getProperty('voices') or [];out=[{'id':v.id,'name':v.name} for v in vs];e.stop();return out
 except:return []
def make_voice(script,path,rate=158,voice_id=None):
 import pyttsx3
 path=Path(path);path.parent.mkdir(parents=True,exist_ok=True);e=pyttsx3.init();e.setProperty('rate',int(rate))
 if voice_id:
  try:e.setProperty('voice',voice_id)
  except:pass
 e.save_to_file(script,str(path));e.runAndWait();e.stop()
 if not path.exists() or path.stat().st_size<1000:raise RuntimeError('TTS audio not created. Check installed Windows speech voices.')
 return path
def ffmpeg_executable():
 """Find system FFmpeg or the portable binary installed by imageio-ffmpeg."""
 candidate = os.environ.get("FFMPEG_BINARY") or shutil.which("ffmpeg")
 if candidate and Path(candidate).exists():
  return str(candidate)
 try:
  import imageio_ffmpeg
  return imageio_ffmpeg.get_ffmpeg_exe()
 except Exception as exc:
  raise RuntimeError("FFmpeg পাওয়া যায়নি। setup_windows.bat আবার চালান অথবা FFmpeg ইনস্টল করে PATH-এ যোগ করুন।") from exc

def audio_duration(audio):
 """Read duration without requiring ffprobe (Windows users often lack ffprobe on PATH)."""
 audio = str(audio)
 ffmpeg = ffmpeg_executable()
 p = subprocess.run([ffmpeg, "-hide_banner", "-i", audio], capture_output=True, text=True)
 output = (p.stderr or "") + "\n" + (p.stdout or "")
 match = re.search(r"Duration:\s*(\d+):(\d+):(\d+(?:\.\d+)?)", output)
 if not match:
  raise RuntimeError("Audio duration পড়া যায়নি। WAV/MP3 ফাইলটি ঠিক আছে কি না দেখুন।")
 h, m, sec = match.groups()
 return max(.1, int(h)*3600 + int(m)*60 + float(sec))
def whisper_word_timestamps(audio,model_size='tiny'):
 try:
  from faster_whisper import WhisperModel
  model=WhisperModel(model_size,device='cpu',compute_type='int8');segments,_=model.transcribe(str(audio),word_timestamps=True,vad_filter=True);words=[]
  for seg in segments:
   for word in (seg.words or []):words.append({'start':float(word.start),'end':float(word.end),'text':word.word.strip()})
  return words or None
 except Exception:return None
def ts(sec):
 ms=max(0,int(round(sec*1000)));h=ms//3600000;ms%=3600000;m=ms//60000;ms%=60000;s=ms//1000;ms%=1000;return f'{h:02}:{m:02}:{s:02},{ms:03}'
def write_srt_from_words(words,path):
 groups=[];cur=[]
 for word in words:
  if cur and (len(cur)>=8 or word['end']-cur[0]['start']>4.5):groups.append(cur);cur=[]
  cur.append(word)
  if re.search(r'[.!?।]$',word['text']):groups.append(cur);cur=[]
 if cur:groups.append(cur)
 lines=[]
 for i,g in enumerate(groups,1):lines += [str(i),f"{ts(g[0]['start'])} --> {ts(g[-1]['end'])}",' '.join(x['text'] for x in g),'']
 Path(path).write_text('\n'.join(lines),encoding='utf-8-sig');return Path(path)
def synchronize_scenes(scenes,audio,word_timestamps=None):
 duration=audio_duration(audio)
 weights=[max(1,len(s.narration.split())) for s in scenes]
 if word_timestamps:
  total_asr=len(word_timestamps); total_script=sum(weights); cursor_words=0
  for i,(scene,count) in enumerate(zip(scenes,weights)):
   begin=min(total_asr-1,round(cursor_words/total_script*total_asr))
   cursor_words+=count
   finish=min(total_asr,round(cursor_words/total_script*total_asr))
   scene.start=max(0.0,word_timestamps[begin]['start'])
   scene.end=(word_timestamps[finish]['start'] if finish<total_asr else word_timestamps[-1]['end'])
   scene.duration=max(.05,scene.end-scene.start)
  if scenes:
   scenes[0].start=0.0;scenes[-1].end=duration;scenes[-1].duration=max(.05,duration-scenes[-1].start)
 else:
  total=sum(weights);cursor=0.0
  for scene,count in zip(scenes,weights):
   scene.duration=duration*count/total;scene.start=cursor;scene.end=cursor+scene.duration;cursor=scene.end
  if scenes:scenes[-1].end=duration;scenes[-1].duration=max(.01,duration-scenes[-1].start)
 return scenes
def write_srt(scenes,path):
 lines=[]
 for i,s in enumerate(scenes,1):lines += [str(i),f'{ts(s.start)} --> {ts(s.end)}',s.narration,'']
 Path(path).write_text('\n'.join(lines),encoding='utf-8-sig');return Path(path)
