from pathlib import Path
from PIL import Image,ImageDraw,ImageFont,ImageFilter
import random
PALETTES={"2D Doodle":((244,235,211),(35,33,29),(183,119,54),(94,112,75)),"3D-style":((24,38,59),(245,231,202),(67,151,180),(190,125,73)),"Documentary":((17,24,32),(239,237,224),(189,145,79),(93,111,124)),"Mixed":((231,224,203),(35,39,39),(171,111,53),(90,112,83))}
def font(n,b=False):
 try:return ImageFont.truetype("C:/Windows/Fonts/arialbd.ttf" if b else "C:/Windows/Fonts/arial.ttf",n)
 except:return ImageFont.load_default()
def generate_scene_images(scenes,output_dir,resolution=(1280,720)):
 out=Path(output_dir);out.mkdir(parents=True,exist_ok=True);paths=[]
 for i,s in enumerate(scenes):
  w,h=resolution;bg,ink,accent,soft=PALETTES.get(s.style,PALETTES["Mixed"]);im=Image.new("RGB",(w,h),bg);d=ImageDraw.Draw(im);random.seed(s.index*97)
  if s.style=="3D-style":
   lay=Image.new("RGBA",(w,h),(0,0,0,0));ImageDraw.Draw(lay).ellipse((w*.58,h*.1,w*.98,h*.7),fill=accent+(130,));lay=lay.filter(ImageFilter.GaussianBlur(30));im=Image.alpha_composite(im.convert("RGBA"),lay).convert("RGB");d=ImageDraw.Draw(im)
  elif s.style=="Documentary":d.rectangle((0,0,w,9),fill=accent);d.rectangle((0,h-9,w,h),fill=accent)
  else:
   for _ in range(24):
    x=random.randrange(w);y=random.randrange(h);r=random.randrange(15,45);d.arc((x-r,y-r,x+r,y+r),0,240,fill=soft,width=2)
  cx,cy=int(w*.73),int(h*.42);txt=(s.title+" "+s.narration).lower()
  if any(k in txt for k in ["clock","time","ঘড়ি","সময়"]):
   r=130;d.ellipse((cx-r,cy-r,cx+r,cy+r),outline=ink,width=9);d.line((cx,cy,cx,cy-r*.65),fill=accent,width=10);d.line((cx,cy,cx+r*.5,cy+r*.2),fill=accent,width=9)
  elif any(k in txt for k in ["book","বই","লেখা"]):
   d.polygon([(cx,cy-120),(cx+145,cy-90),(cx+145,cy+110),(cx,cy+90)],fill=accent,outline=ink);d.polygon([(cx,cy-120),(cx-145,cy-90),(cx-145,cy+110),(cx,cy+90)],fill=soft,outline=ink)
  else:
   d.ellipse((cx-115,cy-115,cx+115,cy+115),fill=soft,outline=ink,width=6);d.rounded_rectangle((cx-75,cy-55,cx+75,cy+65),radius=18,fill=accent,outline=ink,width=5)
  # Recurring simple mascot, stable proportions and palette across all scenes.
  x,y=int(w*.19),int(h*.32);r=48;d.ellipse((x-r,y-r,x+r,y+r),fill=(250,246,231),outline=ink,width=5)
  for dx in (-17,17):d.ellipse((x+dx-4,y-7-4,x+dx+4,y-7+4),fill=ink)
  if i%2:d.ellipse((x-8,y+12,x+8,y+25),fill=ink)
  else:d.arc((x-14,y+5,x+14,y+28),0,180,fill=ink,width=3)
  d.line((x,y+r,x,y+140),fill=ink,width=7);d.line((x,y+90,x-40,y+125),fill=ink,width=7);d.line((x,y+90,x+40,y+125),fill=ink,width=7);d.line((x,y+140,x-28,y+190),fill=ink,width=7);d.line((x,y+140,x+28,y+190),fill=ink,width=7)
  d.rounded_rectangle((w*.34,h*.69,w*.96,h*.94),radius=18,fill=bg,outline=accent,width=3);d.text((w*.37,h*.71),f"SCENE {s.index:02d} | {s.style.upper()}",font=font(20,True),fill=accent)
  title=" ".join(s.title.split()[:10]);d.text((w*.37,h*.78),title[:60],font=font(32,True),fill=ink)
  p=out/f"scene_{i+1:03}.jpg";im.save(p,quality=92);paths.append(p)
 return paths
