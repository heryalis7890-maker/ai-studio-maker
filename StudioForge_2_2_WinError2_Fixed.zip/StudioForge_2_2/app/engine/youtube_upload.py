from pathlib import Path
def upload_video(video_path, title, description, tags, privacy, client_secret):
    video=Path(video_path)
    if not video.exists(): raise FileNotFoundError(f"Video not found: {video}")
    if not client_secret.exists():
        raise RuntimeError("Add Google OAuth client_secret.json. Enable YouTube Data API v3 and configure OAuth consent first.")
    try:
        from google_auth_oauthlib.flow import InstalledAppFlow
        from googleapiclient.discovery import build
        from googleapiclient.http import MediaFileUpload
        scopes=["https://www.googleapis.com/auth/youtube.upload"]
        flow=InstalledAppFlow.from_client_secrets_file(str(client_secret),scopes)
        creds=flow.run_local_server(port=0)
        yt=build("youtube","v3",credentials=creds)
        body={"snippet":{"title":title[:100],"description":description,"tags":tags[:500],"categoryId":"27"},
              "status":{"privacyStatus":privacy,"selfDeclaredMadeForKids":False}}
        # Use a broadly supported category ID for Education.
        body["snippet"]["categoryId"]="27"
        req=yt.videos().insert(part="snippet,status",body=body,
             media_body=MediaFileUpload(str(video),chunksize=-1,resumable=True))
        response=req.execute()
        return "Upload submitted. Video ID: "+response.get("id","unknown")
    except Exception as e:
        raise RuntimeError("YouTube OAuth/upload failed: "+str(e))
