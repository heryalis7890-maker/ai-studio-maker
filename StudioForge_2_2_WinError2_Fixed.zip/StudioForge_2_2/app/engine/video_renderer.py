"""FFmpeg renderer for scene-based narrated MP4."""
from pathlib import Path
import subprocess,json
from .voice_sync import synchronize_scenes,write_srt,whisper_word_timestamps,write_srt_from_words,ffmpeg_executable

def run(cmd):
 try:p=subprocess.run(cmd,capture_output=True,text=True)
 except FileNotFoundError as exc:raise RuntimeError(f"Windows cannot find executable: {cmd[0]}. Re-run setup_windows.bat and verify FFmpeg installation.") from exc
 if p.returncode:
  detail=(p.stderr or p.stdout or 'Unknown FFmpeg error')[-2600:]
  raise RuntimeError('ভিডিও রেন্ডার ব্যর্থ হয়েছে। FFmpeg বার্তা: '+detail)
def render_story_video(scenes,audio,output,workdir,resolution='720p',burn_subtitles=True,word_sync=False,whisper_model='tiny',character=True,fps=25,image_paths=None):
 if not scenes:raise ValueError('No scenes to render')
 audio=Path(audio);output=Path(output);workdir=Path(workdir)
 if not audio.exists():raise FileNotFoundError(f'Voiceover missing: {audio}')
 if not image_paths or len(image_paths)!=len(scenes):raise ValueError('Scene images must be generated before rendering; image count must match scenes.')
 for image in image_paths:
  if not Path(image).exists():raise FileNotFoundError(f'Scene image missing: {image}')
 workdir.mkdir(parents=True,exist_ok=True);output.parent.mkdir(parents=True,exist_ok=True)
 words=whisper_word_timestamps(audio,whisper_model) if word_sync else None;synchronize_scenes(scenes,audio,words)
 ffmpeg=ffmpeg_executable()
 if not Path(ffmpeg).exists():raise RuntimeError(f"FFmpeg binary path does not exist: {ffmpeg}. Run setup_windows.bat again.")
 w,h=(1920,1080) if resolution=='1080p' else (1280,720);clips=[]
 for i,s in enumerate(scenes):
  img=Path(image_paths[i]);clip=workdir/f'clip_{i+1:03}.mp4';dur=max(.6,s.duration)
  zoom="min(zoom+0.0007,1.06)" if i%2==0 else "max(zoom-0.0005,1.0)";vf=f"scale={w}:{h}:force_original_aspect_ratio=increase,crop={w}:{h},zoompan=z='{zoom}':d=1:s={w}x{h}:fps={fps},format=yuv420p"
  run([ffmpeg,'-hide_banner','-loglevel','error','-y','-loop','1','-i',str(img),'-t',f'{dur:.3f}','-vf',vf,'-an','-c:v','libx264','-preset','ultrafast','-crf','25','-pix_fmt','yuv420p',str(clip)]);clips.append(clip)
 concat=workdir/'concat.txt';concat.write_text('\n'.join("file '"+p.resolve().as_posix().replace("'","'\\''")+"'" for p in clips),encoding='utf-8');silent=workdir/'silent.mp4'
 run([ffmpeg,'-hide_banner','-loglevel','error','-y','-f','concat','-safe','0','-i',str(concat),'-c','copy',str(silent)])
 srt=workdir/'captions.srt'
 if words:write_srt_from_words(words,srt);sync='Whisper word timestamps'
 else:write_srt(scenes,srt);sync='Scene-level estimated timing'
 cmd=['ffmpeg','-hide_banner','-loglevel','error','-y','-i',str(silent),'-i',str(audio)]
 if burn_subtitles:
  sf=str(srt.resolve()).replace('\\','/').replace(':','\\:').replace("'","\\'");cmd += ['-vf',f"subtitles='{sf}':force_style='FontName=Arial,FontSize=22,Outline=2,Shadow=1,Alignment=2,MarginV=48'"]
 cmd += ['-map','0:v:0','-map','1:a:0','-c:v','libx264','-preset','ultrafast','-crf','25','-c:a','aac','-b:a','128k','-shortest','-movflags','+faststart',str(output)];run(cmd)
 manifest={'sync_mode':sync,'resolution':resolution,'fps':fps,'scenes':[s.__dict__ for s in scenes]};(workdir/'scene_manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
 return output,srt,manifest
