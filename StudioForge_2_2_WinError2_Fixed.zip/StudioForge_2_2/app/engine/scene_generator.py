"""Editable narration storyboard planner."""
from dataclasses import dataclass,asdict
from pathlib import Path
import json,re,hashlib
@dataclass
class Scene:
 index:int; narration:str; visual_prompt:str; style:str; duration:float; title:str
 shot:str="medium"; action:str="illustrate the narration"; character_id:str="host"; start:float=0.0; end:float=0.0; accent:str="gold"
STYLE={"2D Doodle":"hand-drawn 2D ink doodle, bold black outlines, warm paper texture, expressive simple characters, earthy palette","3D-style":"stylized 2.5D dimensional illustration, layered depth, soft shadows, cinematic composition","Documentary":"cinematic documentary frame, atmospheric depth, archival-inspired props, restrained typography","Mixed":"hybrid of ink illustration, dimensional layers and documentary composition"}
SHOTS=["wide","medium","close-up","over-the-shoulder","top-down","detail"]
ACTIONS=["reveals the central object","examines a key detail","shows cause and effect","moves through the environment","compares past and present","highlights the turning point"]
def _sentences(text):
 text=re.sub(r'\s+',' ',text).strip(); out=[]
 for p in re.split(r'(?<=[.!?।])\s+',text):
  if len(p)>300: out.extend(x.strip() for x in re.split(r'(?<=[,;:])\s+',p) if x.strip())
  elif p.strip():out.append(p.strip())
 return out
def generate_scenes(script,style="Mixed",target_seconds=180,max_scenes=32,character_name="The Host"):
 sentences=_sentences(script)
 if not sentences:raise ValueError("Script is empty.")
 beats=[];buf=""
 for s in sentences:
  if buf and len(buf)+len(s)>230:beats.append(buf);buf=s
  else:buf=(buf+" "+s).strip()
 if buf:beats.append(buf)
 if len(beats)>max_scenes:
  n=(len(beats)+max_scenes-1)//max_scenes;beats=[" ".join(beats[i:i+n]) for i in range(0,len(beats),n)]
 styles=["2D Doodle","3D-style","Documentary"] if style in ("All Styles (Auto Mix)","Mixed","All") else [style]
 weights=[max(1,len(x.split())) for x in beats];total=sum(weights);scenes=[]
 for i,(beat,wt) in enumerate(zip(beats,weights),1):
  chosen=styles[(i-1)%len(styles)];title=" ".join(beat.split()[:8]).strip(" .,!?:;")
  prompt=f"{STYLE.get(chosen,STYLE['Mixed'])}. Shot: {SHOTS[(i-1)%len(SHOTS)]}. Action: {ACTIONS[(i-1)%len(ACTIONS)]}. Subject: {beat[:180]}. Keep recurring character {character_name!r} consistent. Scene key: {hashlib.sha1(beat.encode()).hexdigest()[:8]}."
  scenes.append(Scene(i,beat,prompt,chosen,target_seconds*wt/total,title,SHOTS[(i-1)%len(SHOTS)],ACTIONS[(i-1)%len(ACTIONS)]))
 cursor=0
 for s in scenes:s.duration=round(s.duration,3);s.start=round(cursor,3);cursor+=s.duration;s.end=round(cursor,3)
 if scenes:scenes[-1].end=float(target_seconds)
 return scenes
def save_scenes(scenes,path):
 path=Path(path);path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps([asdict(s) for s in scenes],ensure_ascii=False,indent=2),encoding='utf-8');return path
