"""Robust public YouTube channel research for Windows installations."""
import json
import subprocess
import sys
import urllib.parse
import urllib.request
from pathlib import Path
from PIL import Image, ImageStat


def normalize_channel_url(url: str) -> str:
    raw = (url or "").strip()
    if not raw:
        raise ValueError("একটি public YouTube channel URL দিন।")
    if not raw.startswith(("https://", "http://")):
        raw = "https://" + raw
    parsed = urllib.parse.urlsplit(raw)
    if parsed.netloc.lower() not in {"youtube.com", "www.youtube.com", "m.youtube.com", "youtu.be"}:
        raise ValueError("YouTube channel URL দিন (youtube.com/@channel বা /channel/...)।")
    # Remove tracking parameters such as ?si=...; they are not part of a channel URL.
    clean = urllib.parse.urlunsplit(("https", "www.youtube.com", parsed.path.rstrip("/"), "", ""))
    if parsed.path.startswith("/@") or parsed.path.startswith("/channel/") or parsed.path.startswith("/c/") or parsed.path.startswith("/user/"):
        if not clean.endswith("/videos"):
            clean += "/videos"
    return clean


def _yt_dlp_json(url: str) -> dict:
    # Calling the installed module through the exact Python running Streamlit
    # avoids [WinError 2] when yt-dlp.exe is not on PATH in Windows venvs.
    cmd = [sys.executable, "-m", "yt_dlp", "--ignore-errors", "--no-warnings",
           "--flat-playlist", "--dump-single-json", "--playlist-end", "15", url]
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=180,
                              encoding="utf-8", errors="replace")
    except FileNotFoundError as exc:
        raise RuntimeError(
            f"Python executable পাওয়া যায়নি: {sys.executable}. "
            "run_windows.bat থেকে Studio চালু করুন।"
        ) from exc
    except subprocess.TimeoutExpired as exc:
        raise RuntimeError("YouTube channel analysis ৩ মিনিটের মধ্যে শেষ হয়নি। নেটওয়ার্ক/YouTube access পরীক্ষা করে আবার চেষ্টা করুন।") from exc
    if proc.returncode and not proc.stdout.strip():
        detail = (proc.stderr or "").strip()[-1400:]
        if "No module named yt_dlp" in detail:
            raise RuntimeError("yt-dlp ইনস্টল নেই। Studio folder থেকে repair_environment.bat চালান।")
        raise RuntimeError("YouTube channel data পাওয়া যায়নি: " + (detail or f"yt-dlp exit code {proc.returncode}"))
    raw = proc.stdout.strip()
    # yt-dlp normally prints one JSON object; tolerate informational lines before it.
    start = raw.find("{")
    if start < 0:
        raise RuntimeError("yt-dlp থেকে channel JSON পাওয়া যায়নি। URL public কি না এবং YouTube access আছে কি না দেখুন।")
    try:
        return json.loads(raw[start:])
    except json.JSONDecodeError as exc:
        raise RuntimeError("YouTube response JSON হিসেবে পড়া যায়নি। yt-dlp আপডেট করে আবার চেষ্টা করুন।") from exc


def inspect_channel(url: str):
    channel_url = normalize_channel_url(url)
    data = _yt_dlp_json(channel_url)
    entries = data.get("entries") or []
    items, samples = [], []
    folder = Path(__file__).resolve().parents[2] / "output" / "competitor_thumbnails"
    folder.mkdir(parents=True, exist_ok=True)
    for i, video in enumerate(entries[:15]):
        thumbs = video.get("thumbnails") or []
        thumb_url = (thumbs[-1].get("url") if thumbs else None) or video.get("thumbnail")
        local = None
        if thumb_url:
            try:
                request = urllib.request.Request(thumb_url, headers={"User-Agent": "Mozilla/5.0"})
                with urllib.request.urlopen(request, timeout=20) as response:
                    content = response.read(8 * 1024 * 1024)
                candidate = folder / f"thumb_{i+1:02}.jpg"
                candidate.write_bytes(content)
                with Image.open(candidate) as im:
                    im = im.convert("RGB")
                    sample = im.resize((64, 36))
                    stats = ImageStat.Stat(sample)
                    samples.append({"mean_rgb": [round(x) for x in stats.mean],
                                    "contrast": round(sum(stats.stddev) / 3, 1)})
                local = candidate
            except Exception:
                local = None  # thumbnail failure must not cancel the channel analysis
        items.append({"title": video.get("title") or "Untitled video",
                      "views": video.get("view_count", "not available"),
                      "id": video.get("id"),
                      "thumbnail": str(local) if local else None})

    titles = " ".join(x["title"] for x in items).lower()
    if any(k in titles for k in ("animation", "animated", "cartoon", "doodle", "stickman")):
        style, reason = "2D Doodle", "Public video titles contain animation/cartoon-related terms."
    elif any(k in titles for k in ("documentary", "investigation", "explained", "history")):
        style, reason = "Documentary", "Public video titles suggest documentary/explainer topics."
    else:
        style, reason = "Mixed", "Titles do not prove a specific animation style; Mixed is a cautious starting point."

    channel_name = data.get("title") or data.get("channel") or data.get("uploader") or channel_url
    if not items:
        raise RuntimeError("Channel page পাওয়া গেছে, কিন্তু public video list পাওয়া যায়নি। URL-এর শেষে /videos দিয়ে চেষ্টা করুন অথবা channelটি public কি না দেখুন।")
    return {
        "channel": channel_name,
        "videos": items,
        "style": {"recommended_style": style, "reason": reason,
                  "confidence": "low-to-medium; public titles and available thumbnails only",
                  "thumbnail_visual_samples": samples},
        "note": "Analysis uses public titles and available thumbnails only. It cannot access private analytics, CTR, retention, revenue, or prove the exact animation technique."
    }
