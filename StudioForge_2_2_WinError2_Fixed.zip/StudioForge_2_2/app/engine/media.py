from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
from .voice_sync import make_voice as _make_voice
def make_voice(script,path,rate=158,voice_id=None):return _make_voice(script,path,rate,voice_id)
def make_thumbnail(headline,path,subline="THE STORY EXPLAINED"):
 im=Image.new("RGB",(1280,720),(10,18,31));d=ImageDraw.Draw(im);d.ellipse((760,-160,1420,500),fill=(22,85,104));d.ellipse((850,-70,1330,410),fill=(31,43,75));d.rounded_rectangle((55,70,900,650),radius=28,fill=(12,24,41),outline=(62,207,218),width=4)
 try:big=ImageFont.truetype("C:/Windows/Fonts/arialbd.ttf",72);small=ImageFont.truetype("C:/Windows/Fonts/arialbd.ttf",28)
 except:big=ImageFont.load_default();small=big
 words=headline.split();lines=[];line=""
 for w in words:
  test=(line+" "+w).strip()
  if d.textbbox((0,0),test,font=big)[2]>760 and line:lines.append(line);line=w
  else:line=test
 if line:lines.append(line)
 y=210
 for ln in lines[:3]:d.text((100,y),ln,font=big,fill=(255,221,116),stroke_width=2,stroke_fill=(0,0,0));y+=95
 d.text((102,570),subline.upper(),font=small,fill=(224,241,250));Path(path).parent.mkdir(parents=True,exist_ok=True);im.save(path,quality=94);return Path(path)
