from pathlib import Path
import streamlit as st,re
from engine.research import inspect_channel
from engine.writer import generate_ideas,parse_ideas,generate_script,target_word_count,generate_metadata
from engine.media import make_voice,make_thumbnail
from engine.scene_generator import generate_scenes,save_scenes
from engine.animation_engine import generate_scene_images
from engine.video_renderer import render_story_video
from engine.voice_sync import list_local_voices,ffmpeg_executable
from engine.youtube_upload import upload_video
st.set_page_config(page_title="StudioForge | AI YouTube Studio",page_icon="🎬",layout="wide")
BASE=Path(__file__).resolve().parents[1];OUT=BASE/"output";OUT.mkdir(exist_ok=True)
st.markdown("""<style> :root{--bg:#080d18;--line:#253650;--cyan:#48d7e8} .stApp{background:radial-gradient(ellipse at 12% 0%,#142541,transparent 38%),#080d18;color:#edf4ff} .block-container{max-width:1450px;padding-top:1.4rem} section[data-testid=stSidebar]{background:#0b1525;border-right:1px solid var(--line)} .stTabs [data-baseweb=tab-list]{gap:7px;background:#101a2b;padding:8px;border:1px solid var(--line);border-radius:14px} .stTabs [aria-selected=true]{background:#1a3650;color:white!important;border-radius:9px} .stButton>button,.stDownloadButton>button{background:linear-gradient(110deg,#177d91,#5a50bb);color:white;border:1px solid #39728a;border-radius:10px;font-weight:700;min-height:42px} input,textarea,[data-baseweb=select]>div{background:#0e1929!important;color:#edf4ff!important;border-color:#2a3e59!important;border-radius:9px!important} [data-testid=stMetric]{background:#142239;border:1px solid var(--line);padding:14px;border-radius:13px} .hero{padding:25px;border:1px solid #31506c;border-radius:20px;background:linear-gradient(110deg,#19334e,#181b3c,#103340)} .hero h1{font-size:32px;color:white;margin:6px 0}.hero p{color:#c0cee0;margin:0}.eyebrow{color:var(--cyan);letter-spacing:2px;font-size:11px;font-weight:800}</style>""",unsafe_allow_html=True)
for k,v in {"ideas":[],"script":"","factory_script":"","audio_ready":"","scene_images":[],"video_ready":"","metadata":""}.items():st.session_state.setdefault(k,v)
with st.sidebar:
 st.markdown("## ◈ STUDIOFORGE 2.2");st.caption("AI VIDEO PRODUCTION SUITE · BUILD 2.2");st.divider();st.caption("PROJECT OUTPUT");st.code(str(OUT));
 try:ff=ffmpeg_executable();st.success("FFmpeg Ready" if Path(ff).exists() else "FFmpeg path invalid")
 except Exception as ex:st.error(str(ex))
st.markdown("<div class='hero'><div class='eyebrow'>RESEARCH · SCRIPT · PRODUCE · PUBLISH</div><h1>StudioForge — AI YouTube Automation Studio</h1><p>Competitor insight, selectable topics, long-form narration and a staged production workflow.</p></div>",unsafe_allow_html=True)
tabs=st.tabs(["⌂ Dashboard","◎ Competitor Lab","✦ Topic & Script Lab","▧ Production Factory","▣ Thumbnail & SEO","↗ YouTube Upload","⚙ Settings"])
with tabs[0]:
 a,b,c,d=st.columns(4);a.metric("Pipeline","8 stages");b.metric("Styles","4");c.metric("Long form","1–8 min");d.metric("Output","720p / 1080p")
 st.info("Order: Competitor Analysis → Topic Selection → Full Script → Voiceover → Scene Images → MP4 → Thumbnail → Metadata.")
 for i,x in enumerate(["Competitor analysis","Choose topic","Generate full-length script","Generate voiceover","Generate scene images","Render MP4","Create thumbnail","Generate SEO metadata"],1):st.write(f"**{i:02}.** {x}")
with tabs[1]:
 st.subheader("Competitor channel analysis · Windows-safe yt-dlp")
 url=st.text_input("Public YouTube channel URL",placeholder="https://www.youtube.com/@channel")
 if st.button("Analyze channel",type="primary"):
  try:
   with st.spinner("Reading public video titles and thumbnails..."):st.session_state.research=inspect_channel(url)
  except Exception as ex:st.error(str(ex))
 if "research" in st.session_state:
  r=st.session_state.research;s=r["style"];st.write("**Channel:**",r["channel"]);st.metric("Suggested style",s["recommended_style"]);st.caption(s["reason"]+" Confidence: "+s["confidence"]);st.info(r["note"])
  for v in r["videos"]:
   with st.expander(v["title"] or "Untitled"):
    st.write("Views:",v["views"]);
    if v["thumbnail"] and Path(v["thumbnail"]).exists():st.image(v["thumbnail"],width=250)
  if st.button("Use suggested style"):st.session_state.recommended_style=s["recommended_style"];st.success("Recommendation applied; you can still change it.")
with tabs[2]:
 st.subheader("Select a topic and create the full narration")
 lang=st.selectbox("Language",["English","বাংলা","Hindi","Spanish","Portuguese","Other"],key="language");niche=st.text_input("Channel niche","History and unusual facts");model=st.text_input("Local Ollama model","qwen2.5:1.5b");mins=st.slider("Target video length (minutes)",1,8,8);st.caption(f"Target: about {target_word_count(mins,lang):,} words based on narration pace.")
 if st.button("Generate 8 topic ideas",type="primary"):
  with st.spinner("Generating ideas..."):st.session_state.ideas=parse_ideas(generate_ideas(niche,lang,model))
 if st.session_state.ideas:
  topic=st.selectbox("Choose one topic",st.session_state.ideas,key="topic_choice")
 else:topic=st.text_input("Or write your own topic","The hidden history of an everyday object")
 topic_edit=st.text_input("Edit chosen topic if needed",topic,key="topic_edit")
 if st.button("Generate full-length script",type="primary"):
  if not topic_edit.strip():st.error("Select or enter a topic first.")
  else:
   with st.spinner(f"Writing approximately {target_word_count(mins,lang):,} words..."):
    st.session_state.script=generate_script(topic_edit,niche,lang,mins,model);st.session_state.factory_script=st.session_state.script;st.session_state.script_topic=topic_edit;st.session_state.script_minutes=mins;st.session_state.model=model;st.session_state.language_value=lang;(OUT/"narration_script.txt").write_text(st.session_state.script,encoding="utf-8")
 if st.session_state.script:
  edited=st.text_area("Review and edit narration",st.session_state.script,height=420);count=len(re.findall(r"\b[\w'-]+\b",edited));st.metric("Word count",f"{count:,}")
  if st.button("Save script for production"):st.session_state.script=edited;st.session_state.factory_script=edited;(OUT/"narration_script.txt").write_text(edited,encoding="utf-8");st.success("Saved.")
with tabs[3]:
 st.subheader("Production Factory — follow each stage in order")
 script=st.session_state.factory_script
 if not script:st.warning("Generate and save a script in Topic & Script Lab first.")
 else:
  st.success(f"Script loaded · {len(script.split()):,} words")
  voices=list_local_voices();vmap={v["name"]:v["id"] for v in voices};vname=st.selectbox("Narrator voice",["System default"]+list(vmap));rate=st.slider("Voice speed",115,195,155);styles=["2D Doodle","3D-style","Documentary","Mixed"];suggest=st.session_state.get("recommended_style","Mixed");style=st.selectbox("Visual style",styles,index=styles.index(suggest) if suggest in styles else 3);quality=st.selectbox("Resolution",["720p (recommended)","1080p"]);word_sync=st.checkbox("Optional Whisper word-level subtitles");burn=st.checkbox("Burn subtitles",True)
  st.markdown("#### 01 · Voiceover")
  if st.button("Generate Voiceover",type="primary"):
   try:
    audio=make_voice(script,OUT/"narration.wav",rate,vmap.get(vname));st.session_state.audio_ready=str(audio);st.audio(str(audio));st.success("Voiceover created. Next step unlocked.")
   except Exception as ex:st.error(f"Voiceover failed: {ex}")
  if st.session_state.audio_ready and Path(st.session_state.audio_ready).exists():
   st.audio(st.session_state.audio_ready);st.markdown("#### 02 · Scene images")
   if st.button("Generate storyboard and scene images",type="primary"):
    try:
     scenes=generate_scenes(script,style,int(st.session_state.get("script_minutes",8))*60);st.session_state.scenes=scenes;save_scenes(scenes,OUT/"scene_plan.json");paths=generate_scene_images(scenes,OUT/"scene_images");st.session_state.scene_images=[str(p) for p in paths];st.success(f"Generated {len(paths)} scene images.")
    except Exception as ex:st.error(str(ex))
  if st.session_state.scene_images:
   cols=st.columns(3)
   for i,p in enumerate(st.session_state.scene_images[:15]):
    with cols[i%3]:st.image(p,caption=f"Scene {i+1}",use_container_width=True)
   st.markdown("#### 03 · Final video render")
   if st.button("Render final MP4",type="primary"):
    try:
     ffmpeg=ffmpeg_executable()
     if not Path(ffmpeg).exists():raise RuntimeError(f"FFmpeg file missing: {ffmpeg}. Run setup_windows.bat again.")
     with st.spinner("Rendering scenes and mixing narration..."):
      video,sub,manifest=render_story_video(st.session_state.scenes,st.session_state.audio_ready,OUT/"final_video.mp4",OUT/"render_work","1080p" if quality.startswith("1080") else "720p",burn,word_sync=word_sync,image_paths=st.session_state.scene_images)
     st.session_state.video_ready=str(video);st.success("Video render complete.");st.info(manifest["sync_mode"]);st.video(str(video));st.download_button("Download MP4",video.read_bytes(),file_name="final_video.mp4",mime="video/mp4")
    except Exception as ex:st.error("Render failed");st.code(str(ex))
with tabs[4]:
 st.subheader("Thumbnail first, then metadata")
 if not st.session_state.video_ready:st.warning("Render the final MP4 first.")
 else:
  topic=st.session_state.get("script_topic","Your Story");headline=st.text_input("Thumbnail headline",f"The Hidden Story of {topic}");sub=st.text_input("Supporting text","THE STORY EXPLAINED")
  if st.button("Generate thumbnail",type="primary"):
   p=make_thumbnail(headline,OUT/"thumbnail.jpg",sub);st.session_state.thumbnail=str(p);st.image(str(p),width=640);st.download_button("Download thumbnail",p.read_bytes(),file_name="youtube_thumbnail.jpg",mime="image/jpeg")
  if st.session_state.get("thumbnail"):
   if st.button("Generate SEO metadata"):
    st.session_state.metadata=generate_metadata(topic,st.session_state.factory_script,st.session_state.get("language_value","English"),st.session_state.get("model","qwen2.5:1.5b"));(OUT/"youtube_metadata.txt").write_text(st.session_state.metadata,encoding="utf-8")
   if st.session_state.metadata:st.text_area("Edit metadata",st.session_state.metadata,height=350);st.download_button("Download metadata",st.session_state.metadata,file_name="youtube_metadata.txt")
with tabs[5]:
 st.subheader("YouTube upload")
 video=st.text_input("MP4 path",str(OUT/"final_video.mp4"));title=st.text_input("Title");desc=st.text_area("Description");tags=st.text_input("Tags, comma separated");privacy=st.selectbox("Privacy",["private","unlisted","public"])
 if st.button("Upload video"):
  try:st.success(str(upload_video(video,title,desc,[x.strip() for x in tags.split(",") if x.strip()],privacy,BASE/"client_secret.json")))
  except Exception as ex:st.error(str(ex))
with tabs[6]:
 st.subheader("Engine notes");st.write("Competitor analysis: public titles + thumbnails only; low-to-medium confidence heuristic.");st.write("Image generation: local Pillow scene illustrations, not external AI image synthesis.");st.write("3D style: 2.5D illustration, not full rigged 3D animation.");st.write("Script fallback: long structured draft; fact-check before publishing.");st.warning("8GB RAM PC-তে 720p render ব্যবহার করুন। YouTube API upload requires OAuth setup.")
