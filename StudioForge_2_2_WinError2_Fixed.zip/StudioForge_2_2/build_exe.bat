@echo off
call .venv\Scripts\activate
pyinstaller --onefile --name AIYouTubeStudio launcher.py
echo EXE created in dist folder (if build succeeds).
pause
