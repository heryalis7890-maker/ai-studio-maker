@echo off
setlocal
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe (
 echo Virtual environment not found. Run setup_windows.bat first.
 pause
 exit /b 1
)
echo Repairing packages inside this Studio's own Python environment...
.venv\Scripts\python.exe -m pip install --upgrade pip
.venv\Scripts\python.exe -m pip install --upgrade -r requirements.txt
if errorlevel 1 goto fail
.venv\Scripts\python.exe -c "import yt_dlp, imageio_ffmpeg, PIL, streamlit; print('yt-dlp:',yt_dlp.version.__version__); print('FFmpeg:',imageio_ffmpeg.get_ffmpeg_exe()); print('Streamlit:',streamlit.__version__)"
if errorlevel 1 goto fail
echo Repair complete. Close old Studio windows and run run_windows.bat.
pause
exit /b 0
:fail
echo Repair failed. Check internet access and Python installation.
pause
exit /b 1
